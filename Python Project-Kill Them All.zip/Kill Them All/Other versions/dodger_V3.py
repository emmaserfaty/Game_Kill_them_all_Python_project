#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pygame
import random 

#creation de variables globales
WIDTH=600
SCREEN_HEIGHT= 600
FPS = 60 #pas compris à quoi ça correspond

# 2 types of object: Enemi & Player

#ENEMIS

#vitesse à laquelle les ennemis vont tomber du haut de l'écran (cad cb de cycles fait par la boucle on doit attendre pour le prochain spawn) 2 to 10 )
ENEMY_SPAWN_RATE = 2

# les enemis peuvent avoir des tailles différentes (pixels)
ENEMY_MIN_SIZE = 4
ENEMY_MAX_SIZE = 15

#vitesse à laquelle les ennemis bougent (pixel per frame)
ENEMY_MIN_SPEED1 = 2
ENEMY_MAX_SPEED1 = 10

ENEMY_MIN_SPEED2 = 4
ENEMY_MAX_SPEED2 = 12

ENEMY_MIN_SPEED3 = 6
ENEMY_MAX_SPEED3 = 14

#PLAYERS

#vitesse à laquelle le player bouge (pixel per frame)
PLAYER_SPEED = 4

#taille du player
PLAYER_SIZE = 10

# "hauteur" max que peut atteindre le playeur pour sauter 
PLAYER_MAX_UP = 150


BG_COLOR = pygame.Color("black") #couleur du fond du jeu
TEXT_COLOR = pygame.Color("white") #couleur de l'écriture du jeu
ENEMY_COLOR = pygame.Color("purple") #couleur des ennemis (rouge)
PLAYER_COLOR = pygame.Color("yellow") #couleur du joueur (vert)

# 3 types de classes

#joueur
class Player(pygame.sprite.Sprite):
    
   def __init__(self, width, height):
       super().__init__()
       self.speed = PLAYER_SPEED
       
       self.image = pygame.Surface([width, height])
       
       self.image = pygame.image.load("player.png").convert_alpha()
  
       self.rect = self.image.get_rect()

# we could also try to create a class with all the rectangles, including subclasses ennemy and player
   def draw(self):
       self.image = pygame.image.load("player.png").convert_alpha()
  
       self.rect = self.image.get_rect()

   def move(self, x, y):
       self.rect.x += x
       self.rect.y += y
    
   
   
   def did_hit(self, rect):
       self.rect = self.image.get_rect()
       return self.rect.colliderect(rect)
    
#ennemi tombant du haut de l'écran
class Enemy:
    
    def __init__(self, speed):
        self.size = random.randint(ENEMY_MIN_SIZE, ENEMY_MAX_SIZE)
        self.speed = speed
        self.color = ENEMY_COLOR
        self.position = (random.randint(0, SCREEN_WIDTH - self.size), 0 - self.size)
       

    def draw(self, surface):
        r = self.get_rect()
        pygame.draw.rect(surface, self.color, r)
        
    def move(self):
        self.position = (self.position[0], self.position[1] + self.speed)
        
    def is_off_screen(self):
        return self.position[1] > SCREEN_HEIGHT
    
    def get_rect(self):
        return pygame.Rect(self.position, (self.size, self.size))
        
class Bonus:
    
    def __init__(self, speed):
        self.size = 11
        self.speed = speed
        self.color = pygame.Color("red")
        self.position = (random.randint(0, SCREEN_WIDTH - self.size), 0 - self.size)
        
    def draw(self, surface):
        bonus = self.get_rect()
        pygame.draw.rect(surface, self.color, bonus) 
    
    def move(self):
        self.position = (self.position[0], self.position[1] + self.speed)
        
    def is_off_screen(self):
        return self.position[1] > SCREEN_HEIGHT
    
    def get_rect(self):
        return pygame.Rect(self.position, (self.size, self.size))        

#statut/état du jeu
class World:
    
    #fonction d'initialisation de la classe World
    def __init__(self):
        self.player = Player(20,15) #new player 
        self.enemies = [] #liste des ennemis remise à vide 
        self.bonus = []
        self.gameOver = False
        self.score = 0
        self.level = 1
        self.lives = 1
        self.enemy_counter = 0 # garde en mémoire quand pour la dernière fois on a dessiné un ennemi sur le screen
        
        # on parametre les directions dans lesquelles on peut aller
        self.moveUp = False
        self.moveDown = False
        self.moveLeft = False
        self.moveRight = False
    
    #fonction reset quand le jeu est fini ( reset des variables etc)
    def reset(self) :
        self.player = Player(20,15) #new player 
        self.enemies = [] #liste des ennemis remise à vide `
        self.bonus = []
        self.gameOver = False
        self.score = 0
        self.level = 1
        self.lives = 1
        self.enemy_counter = 0 # garde en mémoire quand pour la dernière fois on a dessiné un ennemi sur le screen
        
        # on parametre les directions dans lesquelles on peut aller
        self.moveUp = False
        self.moveDown = False
        self.moveLeft = False
        self.moveRight = False
        
    #fonction permettant de savoir que le jeu est fini
    def is_game_over(self):
        return self.gameOver
    
    def update(self):
        self.score +=1 # gain d'un point à chaque image du jeu (frame) où le joueur est en vie
        
        if self.moveUp:
            self.player.move(0, -PLAYER_SPEED)
        if self.moveDown:
            self.player.move(0, PLAYER_SPEED)
        if self.moveLeft:
            self.player.move(-PLAYER_SPEED, 0)
        if self.moveRight:
            self.player.move(PLAYER_SPEED, 0)    
        
        for e in self.enemies: 
            e.move()
            if self.player.did_hit(e.get_rect()):
                self.enemies.remove(e)
                self.lives -= 1
                if self.lives == 0:
                    self.gameOver = True
            if e.is_off_screen() == True:
                self.enemies.remove(e)
     
        for b in self.bonus:
            b.move()
            if self.player.did_hit(b.get_rect()):
                if self.lives < 3:
                    self.lives += 1
                    self.bonus.remove(b)
            if b.is_off_screen() == True:
                self.bonus.remove(b)
        
        self.enemy_counter +=1 # incrémentation à chaque frame 
        
        #mise à jour de la liste enemie
        if self.enemy_counter > ENEMY_SPAWN_RATE :
            self.enemy_counter = 0
            if self.score <= 300:
                self.enemies.append(Enemy(random.randint(ENEMY_MIN_SPEED1, ENEMY_MAX_SPEED1)))
                self.level = 1
            elif self.score <= 600 and self.score > 300:
                self.enemies.append(Enemy(random.randint(ENEMY_MIN_SPEED2, ENEMY_MAX_SPEED2)))
                self.level = 2
            elif self.score > 600:
               self.enemies.append(Enemy(random.randint(ENEMY_MIN_SPEED3, ENEMY_MAX_SPEED3)))
               self.level = 3
         
        if self.lives < 3:
            if self.score % 100 ==0:
                self.bonus.append(Bonus(8))
            
            
    def draw(self, surface):
        for e in self.enemies: 
            e.draw(surface)
        for b in self.bonus:
            b.draw(surface)
    
    def handle_keys(self,event): # pas sure d'avoir compris cette fonction ( gère la focntion des touches du clavier ?)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.moveUp = True
            if event.key == pygame.K_DOWN:
                self.moveDown = True
            if event.key == pygame.K_LEFT:
                self.moveLeft = True
            if event.key == pygame.K_RIGHT:
                self.moveRight = True
        
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                self.moveUp = False
            if event.key == pygame.K_DOWN:
                self.moveDown = False
            if event.key == pygame.K_LEFT:
                self.moveLeft = False
            if event.key == pygame.K_RIGHT:
                self.moveRight = False
  
                
                
pygame.init() #configuration de pygame
clock = pygame.time.Clock() # désigne cb de temps est passé entre chaque itération de boucle run"
screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) #création de la fenêtre de jeu 
pygame.display.set_caption ("dodger pygame example") #nom de la fenêtre
    
#creation d'une surface de jeu sur la totalité de la fenêtre créée
surface = pygame.Surface(screen.get_size()) 
surface = surface.convert()


all_sprites = pygame.sprite.Group()
  
#création de l'objet world
world = World()      
playerShip = Player(20,15)
playerShip.rect.x = SCREEN_WIDTH / 2
playerShip.rect.y = SCREEN_HEIGHT - (SCREEN_HEIGHT / 10)
                                  
all_sprites.add(playerShip)




    
#police de caractères
font_name = "8-BIT WONDER.TTF"
font_default = pygame.font.get_default_font()
      

def draw_text(text, font, color, surface, x, y, size):
    font = pygame.font.Font("8-BIT WONDER.TTF", size)
    text_obj = font.render(text, 1, color)
    text_rect = text_obj.get_rect()
    text_rect.topleft = (x,y)
    surface.blit(text_obj, text_rect)
   
            
def main_menu():
   
    while True:
        
        surface.fill(BG_COLOR)
        screen.blit(surface,(0,0))
        
        draw_text('main menu', font_name, TEXT_COLOR, screen, 20, 20, 40)
        
        mx, my = pygame.mouse.get_pos()
        
        button_1 = pygame.Rect(40, 100, 210, 50)
        pygame.draw.rect(screen, (255, 0, 0), button_1)
        draw_text("START", font_name, TEXT_COLOR, screen, 50, 100, 40)
        
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT : # click sur bouton x rouge pour quitter le jeu
                pygame.quit()
                
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                pygame.quit()
                    
            elif button_1.collidepoint((mx, my)):
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        run()
                        world.reset()
         
        pygame.display.update()
        clock.tick()
   

def run() :
   
    #boucle d'évènements (on spécifiera plus tard les différents événements)
    running = True 
    
    while running :
        
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT : # click sur bouton x rouge pour quitter le jeu
                running = False
                
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                running = False
                
            elif event.type == pygame.KEYDOWN and event.key == ord("r"): #si on presse la touche r alors on reset le jeu
                world.reset()
            #on pourrait aussi ajouter une option pour empecher de reset avant qu'une partie ne soit game over
            else :
                world.handle_keys(playerShip, event)
                    
     
                
        # on verifie l'état du jeu (fini ou non)
        if not world.is_game_over() : 
            world.update()
            all_sprites.update
            
             
        surface.fill(BG_COLOR) # "colorisation" de la surface de jeu 
    
        world.draw(surface)
        all_sprites.draw(surface)
        
        screen.blit(surface,(0,0)) # pas compris
        
        draw_text("Score {0}".format(world.score), font_name, TEXT_COLOR, screen, 5, 10, 25)
        draw_text("Level {0}".format(world.level), font_name, TEXT_COLOR, screen, 5, 40, 25)
        draw_text("Lives {0}".format(world.lives), font_name, TEXT_COLOR, screen, 5, 70, 25)
        
        if world.is_game_over() == True:
             draw_text("Game Over", font_name, TEXT_COLOR, screen, (SCREEN_WIDTH / 4 + 10), (SCREEN_HEIGHT / 2 - 30), 30)
             draw_text("Press R to Restart", font_name, TEXT_COLOR, screen, (SCREEN_WIDTH / 9 - 5), (SCREEN_HEIGHT / 2 + 30), 30)
        
        
        clock.tick(FPS) #pas compris
        pygame.display.update() # mise à jour du jeu 

    
        
#test
if __name__ == '__main__':
    main_menu()
    pygame.quit() 