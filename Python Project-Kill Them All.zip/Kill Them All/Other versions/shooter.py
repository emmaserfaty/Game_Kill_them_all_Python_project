# Refonte de tout le code pour pouvoir utiliser des sprites
# Faire en sorte que le code soit plus compréhensible et mieux sectionné
# Frozen Jam by tgfcoder <https://twitter.com/tgfcoder> licensed under CC-BY-3

# Pygame template - skeleton for a new pygame project
import pygame
import random
import os

WIDTH = 480
HEIGHT = 600
FPS = 60

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# initialize pygame and create window
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Dodger Game")
clock = pygame.time.Clock()

font_name = "8-BIT WONDER.TTF"

# set up arts and sounds folders
#game_folder = os.path.dirname(__file__)
img_dir = os.path.join(os.path.dirname(__file__), "img")
snd_dir = os.path.join(os.path.dirname(__file__), "snd")


def draw_text(text, color, surface, x, y, size):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, 1, color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x,y)
    surface.blit(text_surface, text_rect)
    
def draw_lives(surface, x, y, lives, img):
    for i in range(lives):
        img_rect = img.get_rect()
        img_rect.x = x + 30 * i
        img_rect.y = y
        surface.blit(img, img_rect)
    
def new_meteor():
    m = Meteor()
    all_sprites.add(m)
    meteors.add(m)
   

class Player(pygame.sprite.Sprite):
    #sprite for the player
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(player_img, (50, 38))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.radius = 20
        # pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 15
        self.speedx = 0
        self.speedy = 0
        self.shoot_delay = 300
        self.last_shot = pygame.time.get_ticks()
        self.lives = 3
        
    def update(self):
        self.speedx = 0 #we set that we should not move when a key is not pressed
        self.speedy = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT]:
            self.speedx = -5
        if keystate[pygame.K_RIGHT]:
            self.speedx = 5
        if keystate[pygame.K_UP]:
            self.speedy = -5
        if keystate[pygame.K_DOWN]:
            self.speedy = 5
        if keystate[pygame.K_SPACE]:
            self.shoot()
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.top < 450:
            self.rect.top = 450
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
        if self.lives == 0:
            self.game_over = True
            
    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            bullet = Bullet(self.rect.centerx, self.rect.top)
            all_sprites.add(bullet)
            bullets.add(bullet)
            shoot_sound.play()
            
        
class Meteor(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image_orig = random.choice(meteor_images)         # we need to create copies of sprites for rotations
        self.image_orig.set_colorkey(BLACK)
        self.image = self.image_orig.copy()  # otherwise the game is super slow, loss of information while transform.rotate
        self.rect = self.image.get_rect()
        self.radius = int(self.rect.width * .86 / 2)
        # pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
        self.rect.x = random.randrange(WIDTH - self.rect.width)
        self.rect.y = random.randrange(-150, -100)
        self.speedy = random.randrange (1,6)
        self.speedx = random.randrange(-4, 4)
        self.rot = 0
        self.rot_speed = random.randrange(-8,8)
        self.last_update = pygame.time.get_ticks()

        
    def rotate(self):
       now = pygame.time.get_ticks()
       if now - self.last_update > 50:
           self.last_update = now
           self.rot = (self.rot + self.rot_speed) % 360 
           new_image = pygame.transform.rotate(self.image_orig, self.rot)
           old_center = self.rect.center
           self.image = new_image
           self.rect = self.image.get_rect()
           self.rect.center = old_center
           
    def update(self):
        self.rotate()
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        if self.rect.top > HEIGHT + 30 or self.rect.left < -40 or self.rect.right > WIDTH + 40:
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange (1,8)
        

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10

    def update(self):
        self.rect.y += self.speedy
        # kill if it moves off the top of the screen 
        if self.rect.bottom < 0:
            self.kill()
            
            
class Bonus(pygame.sprite.Sprite):
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.image = player_lives_img
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.speedy = 2

    
    def update(self):
        self.rect.y += self.speedy
        # kill if it moves off the top of the screen 
        if self.rect.top > HEIGHT:
            self.kill()


def go_screen():
    screen.blit(background, background_rect)
    
    draw_text("ARROWS TO MOVE, SPACE TO SHOOT",WHITE, screen, WIDTH / 2, HEIGHT / 2, 20)
    draw_text("PRESS A KEY TO START", WHITE, screen, WIDTH / 2, HEIGHT * 3 / 4, 20)
    
    pygame.display.flip()
    waiting = True
    
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
        # check for closing window
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                running = False
            elif event.type == pygame.KEYDOWN:
                    waiting = False
    pygame.display.flip()
    

            

# Load all game graphics
background = pygame.image.load(os.path.join(img_dir, "bg.png")).convert()
background_rect = background.get_rect()
player_img = pygame.image.load(os.path.join(img_dir, "player.png")).convert()
player_lives_img = pygame.transform.scale(player_img, (25, 19))
player_lives_img.set_colorkey(BLACK)
bullet_img = pygame.image.load(os.path.join(img_dir, "laser.png")).convert()
meteor_images = []
meteor_list = ['meteor_t.png', 'meteor_s1.png', 'meteor_s2.png', 'meteor_m1.png', 'meteor_m2.png']
for img in meteor_list:
    meteor_images.append(pygame.image.load(os.path.join(img_dir, img)).convert())

# Load sounds
shoot_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Laser_Shoot23.wav'))
shoot_sound.set_volume(0.3)
bonus_live_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Powerup3.wav'))
bonus_live_sound.set_volume(0.3)
expl_sounds = pygame.mixer.Sound(os.path.join(snd_dir, 'Explosion7.wav'))
expl_sounds.set_volume(0.4)
pygame.mixer.music.load(os.path.join(snd_dir, 'tgfcoder-FrozenJam-SeamlessLoop.ogg'))
pygame.mixer.music.set_volume(0.05)
pygame.mixer.music.play(loops = -1)

player_die_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Explosion40.wav'))
player_die_sound.set_volume(0.3)    

all_sprites = pygame.sprite.Group()
meteors = pygame.sprite.Group()
bullets = pygame.sprite.Group()
bonus = pygame.sprite.Group()
player = Player()
all_sprites.add(player)
for i in range(12):
    new_meteor()
score = 0

# Game loop
game_over = True
running = True


while running:
    if game_over:
        go_screen()
        all_sprites = pygame.sprite.Group()
        meteors = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        bonus = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)
        for i in range(12):
            new_meteor()
        score = 0
        game_over = False
        
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
            running = False
        #elif event.type == pygame.KEYDOWN:
          #  if event.key == pygame.K_SPACE:
            #    player.shoot()

    # Update
    all_sprites.update()
    
    #check to see if a bullet hits a meteor
    hits = pygame.sprite.groupcollide(meteors, bullets, True, True)
    for hit in hits:
        score += 50 - hit.radius
        expl_sounds.play()
        m = Meteor()
        all_sprites.add(m)
        meteors.add(m)
        if player.lives < 3:
            if random.random() > 0.9:
                bonus_live = Bonus(hit.rect.center)
                all_sprites.add(bonus_live)
                bonus.add(bonus_live)
        
    #check to see if a meteor hits the player
    hits = pygame.sprite.spritecollide(player, meteors, True, pygame.sprite.collide_circle)
    for hit in hits:
        player_die_sound.play()
        player.lives -= 1
        new_meteor()
        
        if player.lives == 0:
            game_over = True
            
    hits = pygame.sprite.spritecollide(player, bonus, True)
    for hit in hits:
        if player.lives < 3:
            bonus_live_sound.play()
            player.lives += 1

    # Draw / render
    
    screen.blit(background, background_rect)
    all_sprites.draw(screen)
    draw_text(str(score), WHITE, screen, WIDTH / 2, 10, 20)
    draw_lives(screen, WIDTH - 100, 5, player.lives, player_lives_img)
    # *after* drawing everything, flip the display
    pygame.display.flip()
    
pygame.quit()

