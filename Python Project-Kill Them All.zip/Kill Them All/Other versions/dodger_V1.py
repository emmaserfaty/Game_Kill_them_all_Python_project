#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pygame
import random 

#creation de variables globales

SCREEN_WIDTH=600
SCREEN_HEIGHT= 600
FPS = 40 #pas compris à quoi ça correspond

# 2 types of object: Enemi & Player

#ENEMIS

#vitesse à laquelle les ennemis vont tomber du haut de l'écran (cad cb de cycles fait par la boucle on doit attendre pour le prochain spawn) 2 to 10 )
ENEMY_SPAWN_RATE = 1

# les enemis peuvent avoir des tailles différentes (pixels)
ENEMY_MIN_SIZE = 4
ENEMY_MAX_SIZE = 15

#vitesse à laquelle les ennemis bougent (pixel per frame)
ENEMY_MIN_SPEED = 2
ENEMY_MAX_SPEED = 10

#PLAYERS

#vitesse à laquelle le player bouge (pixel per frame)
PLAYER_SPEED = 4

#taille du player
PLAYER_SIZE = 10

# "hauteur" max que peut atteindre le playeur pour sauter 
PLAYER_MAX_UP = 150


BG_COLOR = pygame.Color("black") #couleur du fond du jeu
TEXT_COLOR = pygame.Color("white") #couleur de l'écriture du jeu
ENEMY_COLOR = pygame.Color("darkred") #couleur des ennemis (rouge)
PLAYER_COLOR = pygame.Color("darkgreen") #couleur du joueur (vert)

# 3 types de classes

#joueur
class Player:
   def __init__(self):
       self.size = PLAYER_SIZE
       self.color = PLAYER_COLOR
       self.speed = PLAYER_SPEED
       self.position = (SCREEN_WIDTH / 2, (SCREEN_HEIGHT - (SCREEN_HEIGHT / 10)))

# we could also try to create a class with all the rectangles, including subclasses ennemy and player
   def draw(self, surface):
       r = self.get_rect()
       pygame.draw.rect(surface, self.color, r)

   def move(self, x, y):
       newX = self.position[0] + x
       newY = self.position[1] + y
       if newX < 0 or newX > SCREEN_WIDTH - PLAYER_SIZE:
           newX = self.position[0]
       if newY < SCREEN_HEIGHT - PLAYER_MAX_UP or newY > SCREEN_HEIGHT - PLAYER_SIZE:
          newY = self.position[1]
       self.position = (newX, newY)
    
   def get_rect(self):
       return pygame.Rect(self.position, (self.size, self.size))
   
   def did_hit(self, rect):
       r = self.get_rect()
       return r.colliderect(rect)
    
#ennemi tombant du haut de l'écran
class Enemy:
    
    def __init__(self):
        self.size = random.randint(ENEMY_MIN_SIZE, ENEMY_MAX_SIZE)
        self.speed = random.randint(ENEMY_MIN_SPEED, ENEMY_MAX_SPEED)
        self.color = ENEMY_COLOR
        self.position = (random.randint(0, SCREEN_WIDTH - self.size), 0 - self.size)
    
    def draw(self, surface):
        r = self.get_rect()
        pygame.draw.rect(surface, self.color, r)
    
    def move(self):
        self.position = (self.position[0], self.position[1] + self.speed)
        
    def is_off_screen(self):
        return self.position[1] > SCREEN_HEIGHT
    
    def get_rect(self):
        return pygame.Rect(self.position, (self.size, self.size))
        
   
#statut/état du jeu
class World:
    
    #fonction d'initialisation de la classe World
    def __init__(self):
        self.reset()
    
    #fonction reset quand le jeu est fini ( reset des variables etc)
    def reset(self) :
        self.player = Player() #new player 
        self.enemies = [] #liste des ennemis remise à vide 
        self.gameOver=False
        self.score = 0
        self.level = 1
        self.enemy_counter = 0 # garde en mémoire quand pour la dernière fois on a dessiné un ennemi sur le screen
        
        # on parametre les directions dans lesquelles on peut aller
        self.moveUp = False
        self.moveDown = False
        self.moveLeft = False
        self.moveRight = False
        
    #fonction permettant de savoir que le jeu est fini
    def is_game_over(self):
        return self.gameOver
    
    def update(self):
        self.score +=1 # gain d'un point à chaque image du jeu (frame) où le joueur est en vie
        
        if self.moveUp:
            self.player.move(0, -PLAYER_SPEED)
        if self.moveDown:
            self.player.move(0, PLAYER_SPEED)
        if self.moveLeft:
            self.player.move(-PLAYER_SPEED, 0)
        if self.moveRight:
            self.player.move(PLAYER_SPEED, 0)
            
        
        for e in self.enemies : 
            e.move()
            if self.player.did_hit(e.get_rect()):
                self.gameOver = True
            if e.is_off_screen() == True:
                self.enemies.remove(e)
        
        self.enemy_counter +=1 # incrémentation à chaque frame 
        
        #mise à jour de la liste enemie
        if self.enemy_counter > ENEMY_SPAWN_RATE :
            self.enemy_counter = 0
            self.enemies.append(Enemy())
        
            
            
    def draw(self, surface):
        self.player.draw(surface)
        for e in self.enemies : 
            e.draw(surface)
    
    def handle_keys(self,event): # pas sure d'avoir compris cette fonction ( gère la focntion des touches du clavier ?)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.moveUp = True
            if event.key == pygame.K_DOWN:
                self.moveDown = True
            if event.key == pygame.K_LEFT:
                self.moveLeft = True
            if event.key == pygame.K_RIGHT:
                self.moveRight = True
        
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                self.moveUp = False
            if event.key == pygame.K_DOWN:
                self.moveDown = False
            if event.key == pygame.K_LEFT:
                self.moveLeft = False
            if event.key == pygame.K_RIGHT:
                self.moveRight = False


def run() :
    pygame.init() #configuration de pygame
    clock = pygame.time.Clock() # désigne cb de temps est passé entre chaque itération de boucle run"
    screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT)) #création de la fenêtre de jeu 
    pygame.display.set_caption ("dodger pygame example") #nom de la fenêtre
    
    #creation d'une surface de jeu sur la totalité de la fenêtre créée
    surface = pygame.Surface(screen.get_size()) 
    surface = surface.convert()
    
    #création de l'objet world
    world= World()
    
    #police de caractères
    font= pygame.font.SysFont("monospace", 42)
    
    
    #boucle d'évènements (on spécifiera plus tard les différents événements)
    running = True 
    
    while running :
        
        for event in pygame.event.get():
            
            if event.type == pygame.QUIT : # click sur bouton x rouge pour quitter le jeu
                running = False
                
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                running = False
                
            elif event.type == pygame.KEYDOWN and event.key == ord("r"): #si on presse la touche r alors on reset le jeu
                world.reset()
            #on pourrait aussi ajouter une option pour empecher de reset avant qu'une partie ne soit game over
            else :
                world.handle_keys(event)
            
        
        clock.tick(FPS) #pas compris
        
        # on verifie l'état du jeu (fini ou non)
        if not world.is_game_over() : 
            world.update()
        
        surface.fill(BG_COLOR) # "colorisation" de la surface de jeu 
    
        world.draw(surface)
        
        screen.blit(surface,(0,0)) # pas compris
        
        text = font.render("Score {0}".format(world.score),1,TEXT_COLOR) # ecriture du score
        screen.blit(text,(5,10)) # affichage du text sur le screen
       
        if world.is_game_over() == True:
            go = font.render("Game Over", 1, TEXT_COLOR)
            screen.blit(go, (SCREEN_WIDTH / 3 + 20, SCREEN_HEIGHT / 2 - 50))
            hr = font.render("Hit R to Reset", 1, TEXT_COLOR)
            screen.blit(hr, (SCREEN_WIDTH / 3 + 20, SCREEN_HEIGHT / 2 + - 5))
        
        pygame.display.update() # mise à jour du jeu 
        
   ## SI ON TEST A CE NIVEAU DU CODE (sans la création des classes) : UNE FENETRE NOIR DOIT APPARAITRE (ce qui n'a pas marché)     
        


    
    
        
#test
if __name__ == '__main__':
    run()
    pygame.quit() 