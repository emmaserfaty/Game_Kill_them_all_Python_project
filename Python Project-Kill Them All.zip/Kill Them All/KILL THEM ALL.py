"""
Please READ ME before running!!
This code is designed to start a game as soon as it is executed.
However, a few steps might be required before running it smoothly.

REQUIREMENTS:
- You will need to download the following list of files and put them in the same folder as this game code:
    - img folder:
        blablabla
    - snd folder:
        blablabla
    - 8-BIT WONDER.TTF (the font)
    - high_score.txt
    
Thank you and enjoy your space trip!
"""

import pygame
import random
import os

WIDTH = 600
HEIGHT = 600
FPS = 60


# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)


# initialize pygame and create window
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Kill them All")
clock = pygame.time.Clock()

font_name = "8-BIT WONDER.TTF"

# set up arts and sounds folders
img_dir = os.path.join(os.path.dirname(__file__), "img")
snd_dir = os.path.join(os.path.dirname(__file__), "snd")

# function to draw text on the screen 
def draw_text(text, color, surface, x, y, size):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, 1, color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x,y)
    surface.blit(text_surface, text_rect)
    
# display the lives (small ships) in the upper right corner
def draw_lives(surface, x, y, lives, img):
    for i in range(lives):
        img_rect = img.get_rect()
        img_rect.x = x + 30 * i
        img_rect.y = y
        surface.blit(img, img_rect)
        
# adds a new meteor 
def new_meteor():
    m = Meteor(level)
    all_sprites.add(m)
    meteors.add(m)

# get the high score from the file
def get_high_score():
    # Default high score
    high_score = 0
 
    # Try to read the high score from a file
    try:
        high_score_file = open("high_score.txt", "r")
        high_score = int(high_score_file.read())
        high_score_file.close()
    except IOError:
        # Error reading file, no high score
        print("There is no high score yet.")
    except ValueError:
        # There's a file there, but we don't understand the number.
        print("I'm confused. Starting with no high score.")
 
    return high_score
 
# save the new high score in the file
def save_high_score(new_high_score):
    try:
        # Write the file to disk
        high_score_file = open("high_score.txt", "w")
        high_score_file.write(str(new_high_score))
        high_score_file.close()
    except IOError:
        # Can't write it.
        print("Unable to save the high score.")
    
   

class Player(pygame.sprite.Sprite): # mandatory paramaters for Sprites
    #sprite for the player
    def __init__(self):
        pygame.sprite.Sprite.__init__(self) # mandatory command to initialize Sprites
        self.image = pygame.transform.scale(player_img, (50, 38))   # load the ship image with correct dimensions (same for other classes)
        self.image.set_colorkey(BLACK)   # set the colorkey to avoid the black background of images
        self.rect = self.image.get_rect()   # we want to get the rectangle associated to the image to work with coordinates
        self.radius = 20    # radius for the circular collision
        #pygame.draw.circle(self.image, RED, self.rect.center, self.radius). test values of radius to optimize circular collisions instead of rectangular
        self.rect.centerx = WIDTH / 2   # x position of the player
        self.rect.bottom = HEIGHT - 15  # y position of the player
        self.speedx = 0      #we set that we should not move when a key is not pressed
        self.speedy = 0
        self.shoot_delay = 250      # we set a delay between to bullet shots (possibility to fire continuously)
        self.last_shot = pygame.time.get_ticks()        # need the time of the last shot to compare it with the delay
        self.lives = 3      # number of lives 
        
    def update(self):
        self.speedx = 0        #we set that we should not move when a key is not pressed
        self.speedy = 0
        keystate = pygame.key.get_pressed()     # update the player frame by frame depending on the input (move or shoot)
        if keystate[pygame.K_LEFT]:     # update the speed to move when arrows are pressed
            self.speedx = -6
        if keystate[pygame.K_RIGHT]:
            self.speedx = 6
        if keystate[pygame.K_UP]:
            self.speedy = -6
        if keystate[pygame.K_DOWN]:
            self.speedy = 6
        if keystate[pygame.K_SPACE]:    # fire a bullet when the spacebar is pressed
            self.shoot()
        self.rect.x += self.speedx      # move according to the speeds defined above
        self.rect.y += self.speedy
        if self.rect.right > WIDTH:     # few lines designed to prevent the player to go outside of a specific screen area
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.top < 450:
            self.rect.top = 450
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
        if self.lives == 0:     # condition allowing to display the game over screen when the player runs out of lives
            self.game_over = True
            
    def shoot(self):    # function to fire bullets
        now = pygame.time.get_ticks()   # get the actual time
        if now - self.last_shot > self.shoot_delay:     # we check that the shoot delay has elapsed before allowing to fire again
            self.last_shot = now    # reset the time of the last shot
            bullet = Bullet(self.rect.centerx, self.rect.top)   # generate a bullet at the center and top of the player's ship
            all_sprites.add(bullet) # need to add it to the global sprite group
            bullets.add(bullet)     # need to add it to the specific sprite group
            shoot_sound.play()      # bullet sound at each bullet
            
        
class Meteor(pygame.sprite.Sprite):
    def __init__(self, level):
        pygame.sprite.Sprite.__init__(self)
        self.image_orig = random.choice(meteor_images)    # for rotations purposes, we need to create copies of the original image
        self.image_orig.set_colorkey(BLACK)
        self.image = self.image_orig.copy()  # otherwise the game is super slow, loss of information while transform.rotate
        self.rect = self.image.get_rect()   # coordinates purposes as in the Player class and other objects
        self.radius = int(self.rect.width * .86 / 2)    # arbitrary values selected after different test to optimize collision detections
        # pygame.draw.circle(self.image, RED, self.rect.center, self.radius) test of a good radius, displays red dots on meteors
        self.rect.x = random.randrange(WIDTH - self.rect.width) # set of a random position above the top of the screen (x and y)
        self.rect.y = random.randrange(-150, -100)
        self.speedy = random.randrange (2 + level, 5 + level)   # set a random speed that depends on the current level for increasing diffculty
        self.speedx = random.randrange(-3, 3)                   # we decided that the x speed has a constant range
        self.rot = 0
        self.rot_speed = random.randrange(-8,8)                 # rotation speed range
        self.last_update = pygame.time.get_ticks()
        

        
    def rotate(self):
       now = pygame.time.get_ticks()
       if now - self.last_update > 50:      # we use the same mechanism as for the bullets to make the meteors rotate
           self.last_update = now
           self.rot = (self.rot + self.rot_speed) % 360  # we change the angle at regular intervals of time (smooth rotation at sight)
           new_image = pygame.transform.rotate(self.image_orig, self.rot) # command to rotate according to the rotation speed defined above on the original image
           old_center = self.rect.center            # without defining a new center for the image, the rotation is weird...
           self.image = new_image                   # because it is operated inside the corresponding rectangle, changing its center. ...
           self.rect = self.image.get_rect()        # Hence, it is important to set a the new rectangle whose is the same as the ...
           self.rect.center = old_center            # previous one to preserve a linear movement.
           
    def update(self):
        self.rotate()                   # try to rotate at each frame
        self.rect.y += self.speedy      # update the position to create the movement (both x and y)
        self.rect.x += self.speedx
        if self.rect.top > HEIGHT + 30 or self.rect.left < -40 or self.rect.right > WIDTH + 40:     # repop the meteors when they go off screen
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange (2 + level, 5 + level)
            self.speedx = random.randrange(-3, 3)
        

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):   # bullet class to defined according to x and y to shoot from the top and center of the ship
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.image.set_colorkey(BLACK) # set the colorkey to avoid the black background of images
        self.rect = self.image.get_rect() # get the associated rectangle to work with coordinates
        self.rect.bottom = y    # set the coordinates to shoot from the top and center of the ship
        self.rect.centerx = x
        self.speedy = -10       # speed of the bullets

    def update(self):
        self.rect.y += self.speedy # moves
        # kill if it moves off the top of the screen 
        if self.rect.bottom < 0:
            self.kill()
            
            
class Bonus(pygame.sprite.Sprite):  # class to drop bonus lives (same mechansim of movement as bullet classe)
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.image = player_lives_img
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.speedy = 2

    
    def update(self):
        self.rect.y += self.speedy # moves
        # kill if it moves off the top of the screen 
        if self.rect.top > HEIGHT:
            self.kill()
            
def start_screen():
    # "blits" (displays) the background and instructions to play
    screen.blit(background, background_rect) 
    draw_text("KILL THEM ALL", RED, screen, WIDTH / 2, 150, 30)
    draw_text("ARROWS TO MOVE",WHITE, screen, WIDTH / 2, HEIGHT / 2, 23)
    draw_text("SPACE TO SHOOT",WHITE, screen, WIDTH / 2, HEIGHT / 2 + 40, 23)
    draw_text("PRESS S KEY TO START", WHITE, screen, WIDTH / 2, HEIGHT * 3 / 4, 20)
    draw_text("PRESS P to Pause", WHITE, screen, WIDTH / 2, HEIGHT * 3 / 4 + 30, 15)
    
    pygame.display.flip() # mandatory elements to display elements on screen
    waiting = True
    while waiting:
        for event in pygame.event.get():
        # check for closing window
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                pygame.quit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_s:
                    waiting = False
        


def go_screen():
    # "blits" (displays) the background, scores and instructions to play
    screen.blit(background, background_rect)
    draw_text("KILL THEM ALL", RED, screen, WIDTH / 2, 150, 30)
    draw_text("PRESS R KEY TO RESTART", WHITE, screen, WIDTH / 2, HEIGHT * 3 / 4, 20)
    draw_text("PRESS S to Pause", WHITE, screen, WIDTH / 2, HEIGHT * 3 / 4 + 30, 15)
    
    # check if the new score if higher than the previous high score and replace it, and diplay the current score / high score
    high_score = get_high_score()
    if score > high_score:
        save_high_score(score)
        draw_text("NEW HIGH SCORE " + str(score),WHITE, screen, WIDTH / 2, HEIGHT / 2, 23)
    else: 
        draw_text("SCORE " + str(score),WHITE, screen, WIDTH / 2, HEIGHT / 2, 23) 
        draw_text("HIGH SCORE " + str(high_score),WHITE, screen, WIDTH / 2, HEIGHT / 2 - 100, 23)
        
    pygame.display.flip() # mandatory elements to display elements on screen
    waiting = True
    while waiting:
        for event in pygame.event.get():
        # check for closing window
            if event.type == pygame.QUIT:
                pygame.quit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                pygame.quit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                    waiting = False
        


def pause():
    # "blits" (displays) the background, scores and instructions to unpause
    screen.blit(background, background_rect)
    draw_text("PAUSED", WHITE, screen, WIDTH / 2, HEIGHT / 2 - 100, 20)
    draw_text("Press P to Continue", WHITE, screen, WIDTH / 2, HEIGHT / 2, 15)
    
    pygame.display.flip() # mandatory elements to display elements on screen
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
                pygame.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:     
                    waiting = False
        

# Load all game graphics
background_origin = pygame.image.load(os.path.join(img_dir, "bg5.jpg")).convert()
background = pygame.transform.scale(background_origin, (600, 600))
background_rect = background.get_rect()
player_img = pygame.image.load(os.path.join(img_dir, "player.png")).convert()
player_lives_img = pygame.transform.scale(player_img, (25, 19))
player_lives_img.set_colorkey(BLACK)
bullet_img = pygame.image.load(os.path.join(img_dir, "laser.png")).convert()
meteor_images = []  # need to create a list because the meteors can be of 5 different types
meteor_list = ['meteor_t.png', 'meteor_s1.png', 'meteor_s2.png', 'meteor_m1.png', 'meteor_m2.png']
for img in meteor_list:
    meteor_images.append(pygame.image.load(os.path.join(img_dir, img)).convert())

# Load sounds
shoot_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Laser_Shoot23.wav'))
shoot_sound.set_volume(0.3)
bonus_live_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Powerup3.wav'))
bonus_live_sound.set_volume(0.3)
expl_sounds = pygame.mixer.Sound(os.path.join(snd_dir, 'Explosion7.wav'))
expl_sounds.set_volume(0.4)
pygame.mixer.music.load(os.path.join(snd_dir, 'tgfcoder-FrozenJam-SeamlessLoop.ogg'))
pygame.mixer.music.set_volume(0.05)
pygame.mixer.music.play(loops = -1) # the music starts again as soon as it ends
player_die_sound = pygame.mixer.Sound(os.path.join(snd_dir, 'Explosion40.wav'))
player_die_sound.set_volume(0.3)    


# Game loop
game_over = False
running = True
start = True
level = 1

# check the state, displays the corresponding screen, and initializes all sprites and paramaters or resets them if game over
while running:
    if start:
        start_screen()
        start = False
        all_sprites = pygame.sprite.Group()
        meteors = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        bonus = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)
        for i in range(12):
            new_meteor()
        score = 0
    if game_over:
        pygame.time.delay(300)
        go_screen()
        game_over = False
        all_sprites = pygame.sprite.Group()
        meteors = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        bonus = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)
        level = 1
        for i in range(12):
            new_meteor()
        score = 0
        
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: #esc --> on quitte le jeu
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_p:
            pause()

    # Update
    all_sprites.update()
    
    #check to see if a bullet hits a meteor and update the score and level
    hits = pygame.sprite.groupcollide(meteors, bullets, True, True) # set paramaters to True to kill the sprites after collisions
    for hit in hits:
        score += 50 - hit.radius
        if score < 500:
            level = 1      
        else:
            level = score // 500 + 1
        expl_sounds.play()
        m = Meteor(level)       # generate a new meteor for each meteor destroyed
        all_sprites.add(m)
        meteors.add(m)
        if player.lives < 3:    # if lives are less then 3, drop a bonus live with a probability of 10% for each meteor destroyed
            if random.random() > 0.9:
                bonus_live = Bonus(hit.rect.center)
                all_sprites.add(bonus_live)
                bonus.add(bonus_live)
        
    #check to see if a meteor hits the player
    hits = pygame.sprite.spritecollide(player, meteors, True, pygame.sprite.collide_circle)
    for hit in hits:
        player_die_sound.play()
        player.lives -= 1
        new_meteor()
        
        if player.lives == 0:       # check the number of lives and display the game over screen if the player runs out of lives
            game_over = True
            
    hits = pygame.sprite.spritecollide(player, bonus, True)
    for hit in hits:
        if player.lives < 3:
            bonus_live_sound.play()
            player.lives += 1

    # Draw / render
    
    screen.blit(background, background_rect)
    all_sprites.draw(screen)
    draw_text(str(score), WHITE, screen, WIDTH / 2, 10, 20)
    draw_text("Level " + str(level), WHITE, screen, 70, 10, 20)
    draw_lives(screen, WIDTH - 100, 5, player.lives, player_lives_img)
    # *after* drawing everything, flip the display
    pygame.display.flip()
    
pygame.quit()

# Frozen Jam by tgfcoder <https://twitter.com/tgfcoder> licensed under CC-BY-3